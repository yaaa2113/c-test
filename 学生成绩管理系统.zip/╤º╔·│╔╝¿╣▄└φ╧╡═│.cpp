﻿#include <cstdio>
#include<cstring>
#include <cstdlib>
#define LEN sizeof(LinkList)

typedef struct LNode
{
    char name[10];
    int num[1];
    int score[3];//0、1、2分别为语文、数学、英语
    struct LNode* next;
} LinkList;

typedef struct lnode
{
    int tag;//节点类型标识
    union
    {
        int Class;//班级
        struct LNode* sublist;
    }val;
    struct lnode* link;//指向下一个元素
}GLNode;

LinkList* init()
{
    return NULL;      /*返回空指针*/
}

//输入学生信息
LinkList* create()
{
    int i, k;
    int j;
    GLNode* L;
    L = (GLNode*)malloc(sizeof(GLNode));
    LinkList* head = NULL, * p;  /* 定义函数.此函数带回一个指向链表头的指针*/
    system("cls");
    printf("\n请输入您想输入的学生个数：");
    scanf_s("%d", &k);
    for (j = 0; j < k; j++)
    {
        p = (LinkList*)malloc(LEN);      /*开辟一个新的单元*/
        if (p == NULL)       /*如果指针p为空*/
        {
            printf("\n输出内存溢出.");       /*输出内存溢出*/
            return (head);      /*返回头指针,下同*/
        }
        printf("输入学号:");
        scanf_s("%d", &p->num[0]);
        printf("输入姓名:");
        scanf_s("%s", p->name);
        printf("请分别输入语文、数学、英语的分数 %d scores\n", 3);/*开始输入*/
        for (i = 0; i < 3; i++)        /*3门课程循环3次*/
        {
            do {
                printf("score%d:", i + 1);
                scanf_s("%d", &p->score[i]);
                if (p->score[i] < 0 || p->score[i]>100) /*确保成绩在0~100之间*/
                    printf("Data error,please enter again.\n");
            } while (p->score[i] < 0 || p->score[i]>100);
        }
        p->next = head;               /*将头结点做为新输入结点的后继结点*/
        head = p;                     /*新输入结点为新的头结点*/
    }

    return(head);
}

//输出学生记录
void print(LinkList* head)
{
    LinkList* p;
    system("cls");
    p = head;
    printf("\n************************LinkList***************\n");
    printf("-------------------------------------------------\n");
    printf("| 学号  |   姓名  |  语文 |  数学  |  英语  | \n");
    printf("-------------------------------------------------\n");
    while (p != NULL)
    {
        printf("| %d   |   %-4s  |  %3d  |  %3d  |  %3d  |\n", p->num[0], p->name, p->score[0], p->score[1], p->score[2]);
        p = p->next;
    }
    printf("-------------------------------------------------\n");
    printf("***********************END***********************\n");
}

/*删除记录函数*/
void Delete(LinkList*& head)
{
    LinkList* p1, * p2;
    char c;
    int s = 0;
    system("cls");
    printf("请输入要删除的学生的学号: ");
    scanf_s("%d", &s);
    p1 = p2 = head;
    while (p1->num[0] != s && p1 != NULL)
    {
        p2 = p1;
        p1 = p1->next;
    }
    if (p1->num[0] == s)
    {
        printf("***********************FOUND************************\n");
        printf("-----------------------------------------------------------\n");
        printf("| 学号  |   姓名   |  语文  |   数学  |  英语  |\n");
        printf("-------------------------------------------------\n");
        printf("|  %d  |    %4s   |   %3d  |   %3d   |   %3d   |\n", p1->num[0], p1->name, p1->score[0], p1->score[1], p1->score[2]);
        printf("-----------------------------------------------------\n");
        printf("**************************END**************************\n");
        printf("您确定要删除该学生的记录吗 Y/N ?");
        for (;;)
        {
            scanf_s("%c", &c);
            if (c == 'n' || c == 'N') break;
            if (c == 'y' || c == 'Y')
            {
                if (p1 == head)
                    head = p1->next;
                else
                    p2->next = p1->next;
                free(p1);
                printf("\n学号为 %d 的学生记录已被删除.\n", s);
                break;
            }
        }
    }
    else
        printf("\n找不到学号为 %d 的学生记录.\n", s);
    return;
}

//插入
void Insert(LinkList*& head)
{
    int k;
    printf("请输入插入的位置：");
    scanf_s("%d", &k);
    int j = 0, i;
    LinkList* p1, * p2;
    char s[10];
    int N;
    int score[3];
    system("cls");
    printf("输入学号:");
    scanf_s("%d", &N);
    printf("输入姓名:");
    scanf_s("%s", s);
    printf("请分别输入语文、数学、英语的分数 %d scores\n", 3);
    for (i = 0; i < 3; i++)
    {
        do {
            printf("score%d:", i + 1);
            scanf_s("%d", &score[i]);
            if (score[i] < 0 || score[i]>100)
                printf("Data error,please enter again.\n");
        } while (score[i] < 0 || score[i]>100);
    }
    p1 = head;
    while (j < k - 1 && p1 != NULL)
    {
        j++;
        p1 = p1->next;
    }
    if (p1 == NULL)   return;
    else
    {
        p2 = (LinkList*)malloc(LEN);
        p2->num[0] = N;
        strcpy_s(p2->name, s);
        for (i = 0; i < 3; i++)
            p2->score[i] = score[i];
        p2->next = p1->next;
        p1->next = p2;

    }
}

//菜单
void menu_select()
{
    printf("\n\n\n");
    printf("****************************************************\n");
    printf("\t               Welcome to                  \n");
    printf("\t      The student score manage system         \n");
    printf("**********************MENU**************************\n");
    printf("\t\t1. 输入学生记录\n");
    printf("\t\t2. 输出学生记录\n");
    printf("\t\t3. 删除学生记录\n");
    printf("\t\t4. 插入一个新的学生记录\n");
    printf("\t\t5. 排序\n");
    printf("\t\t6. 统计及格人数\n");
    printf("\t\t7.退出\n");
    printf("****************************************************\n");
}

//排序
void sort(int a[], int N)
{
    int i, j, k;
    for (i = 0; i <= N - 1; i++)
    {
        for (j = 0; j < N - i - 1; j++)
        {
            if (a[j] > a[j + 1])
            {
                k = a[j];
                a[j] = a[j + 1];
                a[j + 1] = k;
            }
        }
    }
}

//排序
LinkList* order(LinkList* head) {
    LinkList* p, * p1, * p2, * p3, * p4;
    int t[100];
    int k = 0;
    p = head;
    p2 = (LinkList*)malloc(LEN);
    p4 = (LinkList*)malloc(LEN);
    while (p != NULL) {
        t[k] = p->num[0];
        k++;
        p = p->next;
    }
    sort(t, k);
    int w = 0;
    p3 = head;
    p1 = p4;
    while (w < k) {
        while (p3->num[0] != t[w]) {
            p3 = p3->next;
        }
        p2->num[0] = p3->num[0];
        p2->score[0] = p3->score[0];
        p2->score[1] = p3->score[1];
        p2->score[2] = p3->score[2];
        strcpy_s(p2->name, p3->name);
        p4->next = p2;
        p4 = p4->next;
        p2 = (LinkList*)malloc(LEN);
        p3 = head;
        w++;
    }
    return p1->next;
}

//成绩的分类合计
void SumList(LinkList* R)
{
    int a = 0, b = 0, c = 0, A = 0, B = 0, C = 0;
    LinkList* p, * p1;
    p = p1 = R;
    int e = 0;
    int k = 0;
    int s[100], y[100], w[100];
    while (p != NULL) {
        k++;
        p = p->next;
    }
    while (p1 != NULL) {
        for (int i = 0; i < 3; i++) {
            if (i == 0) {
                w[e] = p1->score[0];
            }
            else if (i == 1) {
                s[e] = p1->score[1];
            }
            else {
                y[e] = p1->score[2];
            }
        }
        e++;
        p1 = p1->next;
    }
    for (int j = 0; j < e; j++) {
        if (w[j] < 60) {
            a++;
        }
        else {
            A++;
        }
        if (s[j] < 60) {
            b++;
        }
        else {
            B++;
        }
        if (y[j] < 60) {
            c++;
        }
        else {
            C++;
        }
    }
    printf("语文及格人数 = %d\t 不及格人数 = %d\n", A, a);
    printf(" 数学及格人数 = %d\t 不及格人数 = %d\n", B, b);
    printf(" 英语及格人数 = %d\t 不及格人数 = %d\n", C, c);

}

//按班级录入学生成绩
void creatclass(GLNode* L, LinkList* student,int n)
{
    GLNode* s;
    s = (GLNode*)malloc(sizeof(GLNode));
    s->val.Class = n;
    s->val.sublist = student;
    s->link = L->link;  //将s节点插入到原首节点之前，头结点之后 
    L->link = s;
    return;
}

//按班级输出学生信息
void printclass(int n,GLNode *L)
{ 
    GLNode* t=L;
    LinkList* s=t->val.sublist;
    while (s->next != NULL)
    {
        while (t->val.Class == n)
        {
            s = t->val.sublist;
            printf("========================================");
            print(s);
            printf("========================================");
        }
        t = t->link;
    }
    return;
}

//菜单函数
void ScoreManage()
{
    LinkList* head;
    int n;
    head = init();
    menu_select();
    do {
        printf("\n\t\t输入您的选择(1~7):");
        scanf_s("%d", &n);
    } while (n < 1 || n>7);
    for (;;)
    {
        switch (n)
        {
        case 1:head = create(); break;
        case 2:print(head); break;
        case 3:Delete(head); break;
        case 4:Insert(head); break;
        case 5:head = order(head); break;
        case 6:SumList(head); break;
        case 7:return;
        }
        menu_select();
        printf("\n\t\t\t输入您的选择(1~7):");
        scanf_s("%d", &n);
    }
}

int main()
{
    ScoreManage();
}
